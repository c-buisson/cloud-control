log_level                :info
log_location             STDOUT
cache_type               'BasicFile'
node_name                'admin'
client_key               '/opt/knife/admin.pem'
chef_server_url          'https://CHEF_SERVER_CONTAINER_IP:443/organizations/my_org'
ssl_verify_mode          :verify_none
